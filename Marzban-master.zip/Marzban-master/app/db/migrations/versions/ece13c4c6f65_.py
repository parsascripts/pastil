"""empty message

Revision ID: ece13c4c6f65
Revises: d02dcfbf1517, b3378dc6de01
Create Date: 2023-02-23 14:55:19.953972

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ece13c4c6f65'
down_revision = ('d02dcfbf1517', 'b3378dc6de01')
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
